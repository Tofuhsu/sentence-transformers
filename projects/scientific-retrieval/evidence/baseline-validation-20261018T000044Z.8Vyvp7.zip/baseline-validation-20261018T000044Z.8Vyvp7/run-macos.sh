#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
set -uo pipefail

SR_BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" || exit 1
SR_REPO="${1:-$HOME/scientific-retrieval-finetuning}"
SR_BASE="b0bf39968ba461c34b29372144794eff1be06f6d"
SR_PREVIOUS="$HOME/scientific-retrieval-evidence/metrics-check-20261017T230215Z.ucjcjJ"
SR_TOKEN="$HOME/scientific-retrieval-evidence/token-audit-cache-fix-20261017T225329Z.gAjsX3"
if [ "$(uname -s)" != Darwin ]; then
  printf 'This runner is for your Mac.\n'; exit 1
fi
cd "$SR_REPO" || exit 1
mkdir -p "$HOME/scientific-retrieval-evidence" "$HOME/scientific-retrieval-artifacts/retrieval-baselines" || exit 1
SR_RUN_DIR="$(mktemp -d "$HOME/scientific-retrieval-evidence/baseline-validation-$(date -u +%Y%m%dT%H%M%SZ).XXXXXX")" || exit 1
SR_ARTIFACT_DIR="$HOME/scientific-retrieval-artifacts/retrieval-baselines/$(basename "$SR_RUN_DIR")"
SR_PROJECT="$SR_REPO/projects/scientific-retrieval"
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export PYTORCH_ENABLE_MPS_FALLBACK=0 PYTORCH_MPS_FAST_MATH=0
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
export MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false

(
  set -e
  [ "$(git branch --show-current)" = experiment/scifact-hard-negatives ] &&
    [ "$(git rev-parse HEAD)" = "$SR_BASE" ] &&
    [ "$(git rev-parse 'scientific-retrieval-baseline^{commit}')" = "$SR_BASE" ] || {
      printf 'Unexpected branch or baseline; stopped.\n'; exit 1;
    }
  git diff --exit-code
  git diff --cached --exit-code
  (cd "$SR_BUNDLE_DIR" && shasum -a 256 -c SHA256SUMS)
  .venv/bin/python - "$SR_PREVIOUS" "$SR_TOKEN" "$SR_PROJECT" "$SR_RUN_DIR" <<'PY'
import hashlib
import json
from pathlib import Path
import platform
import sys

previous, token, project, output = map(Path, sys.argv[1:])
def require(ok, message):
    if not ok:
        raise SystemExit(message)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def verify_evidence(root, expected_manifest):
    manifest = root / "SHA256SUMS"
    require(digest(manifest) == expected_manifest, f"Evidence manifest changed: {root.name}")
    entries = manifest.read_text(encoding="utf-8").splitlines()
    for line in entries:
        expected, name = line.split("  ", 1)
        path = root / name
        require(path.resolve().is_relative_to(root.resolve()), "Invalid evidence path")
        require(digest(path) == expected, f"Evidence checksum mismatch: {root.name}/{name}")
    require((root / "exit-code.txt").read_text().strip() == "0", f"Prior stage failed: {root.name}")
    print(f"Verified {len(entries)} evidence files: {root.name}")
require(sys.prefix != sys.base_prefix and Path(sys.prefix).resolve() == (Path.cwd() / ".venv").resolve(),
        "Unexpected Python environment")
require(platform.machine() == "arm64", "Expected native arm64 Python")
verify_evidence(previous, "6ac4b016e03a7780d414f6f08920c7e95f9328060c1ad4c7c190499f2a4abb87")
verify_evidence(token, "911f6a8316c9cbf2382d6448cfa1fa57c686454b49e73e2c7393b85909c7dd55")
metric_check = json.loads((previous / "results/metric-verification.json").read_text())
require(metric_check["status"] == "passed" and metric_check["known_answer_cases"] == 7,
        "Prior metric checks did not pass")
for code in ("tests-exit-code.txt", "verification-exit-code.txt", "cli-exit-code.txt"):
    require((previous / code).read_text().strip() == "0", f"Prior {code} was not zero")
sources = sorted(p for p in (previous / "source").iterdir() if p.is_file())
for source in sources:
    require(source.read_bytes() == (project / source.name).read_bytes(),
            f"Previously verified source changed: {source.name}")
print(f"Verified {len(sources)} existing project files")
(output / "run-inputs.json").write_text(json.dumps({
    "metrics_evidence": str(previous), "metrics_manifest_sha256": digest(previous / "SHA256SUMS"),
    "token_evidence": str(token), "token_manifest_sha256": digest(token / "SHA256SUMS"),
    "previous_sources_sha256": {p.name: digest(p) for p in sources},
}, indent=2, sort_keys=True) + "\n")
for name in ("runtime.json", "token-audit.json"):
    (output / f"prior-token-{name}").write_bytes((token / "results" / name).read_bytes())
print("Python:", sys.version)
print("Executable:", sys.executable)
PY
  SR_FILES=(retrieval_runtime.py test_retrieval_runtime.py retrieval_baseline.py BASELINE.md)
  for SR_NAME in "${SR_FILES[@]}"; do
    if [ -e "$SR_PROJECT/$SR_NAME" ] && ! cmp -s "$SR_BUNDLE_DIR/project/$SR_NAME" "$SR_PROJECT/$SR_NAME"; then
      printf 'Existing file differs; stopped: %s\n' "$SR_PROJECT/$SR_NAME"; exit 1
    fi
  done
  for SR_NAME in "${SR_FILES[@]}"; do
    if [ ! -e "$SR_PROJECT/$SR_NAME" ]; then
      cp "$SR_BUNDLE_DIR/project/$SR_NAME" "$SR_PROJECT/$SR_NAME"
    fi
  done
  mkdir "$SR_RUN_DIR/source"
  cp "$SR_BUNDLE_DIR/run-macos.sh" "$SR_RUN_DIR/run-macos.sh"
  cp "$SR_BUNDLE_DIR/RUN-ME.txt" "$SR_RUN_DIR/RUN-ME.txt"
  for SR_SOURCE in "$SR_PREVIOUS/source/"*; do
    cp "$SR_PROJECT/$(basename "$SR_SOURCE")" "$SR_RUN_DIR/source/"
  done
  for SR_NAME in "${SR_FILES[@]}"; do
    cp "$SR_PROJECT/$SR_NAME" "$SR_RUN_DIR/source/$SR_NAME"
  done
  {
    date -u
    sw_vers
    uname -m
    .venv/bin/python --version
    git rev-parse HEAD
    git status --short --branch
    /usr/bin/pmset -g batt
    printf 'Encoding: MPS float32; retrieval: exact CPU cosine; validation only\n'
  } > "$SR_RUN_DIR/environment.txt" 2>&1
  .venv/bin/python -m pip freeze --all > "$SR_RUN_DIR/dependencies.txt"

  if .venv/bin/python -m unittest discover -s "$SR_PROJECT" -p 'test_*.py' -v \
      2>&1 | tee "$SR_RUN_DIR/tests.log"; then SR_TEST_EXIT=0; else SR_TEST_EXIT=$?; fi
  printf '%s\n' "$SR_TEST_EXIT" > "$SR_RUN_DIR/tests-exit-code.txt"
  [ "$SR_TEST_EXIT" -eq 0 ] || exit "$SR_TEST_EXIT"

  if .venv/bin/python -u "$SR_PROJECT/retrieval_baseline.py" \
      --split-lock "$SR_PROJECT/split-lock.json" \
      --text-policy "$SR_PROJECT/text-policy.json" \
      --data-audit "$HOME/scientific-retrieval-evidence/data-audit-20261017T214239Z.wuW5KT" \
      --token-audit "$SR_TOKEN" \
      --cache-dir "$HOME/scientific-retrieval-artifacts/hf-cache" \
      --output-dir "$SR_RUN_DIR/results" \
      --artifact-dir "$SR_ARTIFACT_DIR" \
      2>&1 | tee "$SR_RUN_DIR/baseline.log"; then SR_BASELINE_EXIT=0; else SR_BASELINE_EXIT=$?; fi
  printf '%s\n' "$SR_BASELINE_EXIT" > "$SR_RUN_DIR/baseline-exit-code.txt"
  [ "$SR_BASELINE_EXIT" -eq 0 ] || exit "$SR_BASELINE_EXIT"
  git diff --check
  git status --short --branch
  printf '\nTests=%s Baseline=%s\n' "$SR_TEST_EXIT" "$SR_BASELINE_EXIT"
) 2>&1 | tee "$SR_RUN_DIR/stage.log"

SR_EXIT=$?
printf '%s\n' "$SR_EXIT" > "$SR_RUN_DIR/exit-code.txt"
if .venv/bin/python - "$SR_RUN_DIR" <<'PY'
import hashlib
from pathlib import Path
import sys
root = Path(sys.argv[1])
files = sorted(p for p in root.rglob("*") if p.is_file() and p != root / "SHA256SUMS")
(root / "SHA256SUMS").write_text("".join(
    f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root)}\n" for p in files
), encoding="utf-8")
PY
then
  if (cd "$(dirname "$SR_RUN_DIR")" && /usr/bin/zip -qr "$SR_RUN_DIR.zip" "$(basename "$SR_RUN_DIR")"); then
    printf 'Evidence ZIP: %s.zip\n' "$SR_RUN_DIR"
  else
    printf 'Evidence ZIP creation failed.\n'; SR_EXIT=1
  fi
else
  printf 'Evidence checksum generation failed.\n'; SR_EXIT=1
fi
printf 'Stage exit code: %s\nEvidence directory: %s\nArtifacts directory: %s\n' "$SR_EXIT" "$SR_RUN_DIR" "$SR_ARTIFACT_DIR"
exit "$SR_EXIT"
